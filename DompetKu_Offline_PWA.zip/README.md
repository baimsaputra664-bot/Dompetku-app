# DompetKu Offline-first PWA

## Isi paket
- `index.html`: aplikasi keuangan (HTML, CSS, JavaScript)
- `manifest.webmanifest`: metadata instalasi PWA
- `sw.js`: cache aplikasi untuk penggunaan offline setelah kunjungan pertama
- `icon.svg`, `icon-192.png`, `icon-512.png`: ikon aplikasi

## Fitur offline-first
- Data aplikasi disimpan di IndexedDB.
- Migrasi otomatis dari LocalStorage versi prototipe lama jika ditemukan.
- Backup data ke JSON dan restore dari file JSON.
- Lampiran foto bukti disimpan sebagai data lokal di IndexedDB bersama data transaksi.
- Service worker melakukan cache aset untuk akses offline setelah aplikasi dibuka saat online.
- Tidak memerlukan login atau server database.

## Cara mencoba
1. Ekstrak ZIP.
2. Buka `index.html` untuk mencoba fitur dasar. IndexedDB dan backup/restore biasanya berjalan di browser modern.
3. Untuk PWA yang dapat dipasang dan service worker/offline cache, sajikan folder ini melalui HTTPS atau localhost. Contoh jika Python terpasang: `python -m http.server 8000`, lalu buka `http://localhost:8000`.
4. Di Chrome Android, buka URL tersebut, lalu pilih menu browser > **Tambahkan ke layar utama** atau **Install app** jika tersedia.

## Catatan
- PWA/service worker tidak aktif ketika halaman dibuka langsung melalui `file://`; gunakan HTTPS atau localhost.
- Data tersimpan hanya pada browser/perangkat ini. Hapus data situs/browser dapat menghapus data lokal; lakukan backup JSON secara berkala.
- Ini prototipe lokal, bukan sistem akuntansi terverifikasi. Jangan gunakan sebagai satu-satunya arsip keuangan tanpa backup.
- Fitur transaksi berulang pada prototipe sebelumnya masih berupa konsep/struktur, belum menjalankan scheduler otomatis.
